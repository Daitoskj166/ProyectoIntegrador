package vista;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class ProductoController {

    @FXML 
    private TableColumn<?, ?> ColumnCantidad;

    @FXML
    private TableColumn<?, ?> ColumnIdUsuario;

    @FXML
    private TableColumn<?, ?> ColumnNombre;

    @FXML
    private TableColumn<?, ?> ColumnReferenciaProducto;

    @FXML
    private TableColumn<?, ?> ColumnValorTotal;

    @FXML
    private TableColumn<?, ?> ColumnvalorUnitario;

    @FXML
    private Button buttonActualizar;

    @FXML
    private Button buttonCrear;

    @FXML
    private TextField textCantidad;

    @FXML
    private TextField textIdUsuario;

    @FXML
    private TextField textNombre;

    @FXML
    private TextField textReferenciaProducto;

    @FXML
    private TextField textValorTotal;

    @FXML
    private TextField textValorUnitario;

    @FXML
    void ColumnIdFactura(ActionEvent event) {

    }

    @FXML
    void ColumnIdUsuario(ActionEvent event) {

    }

    @FXML
    void ColumnIdVenta(ActionEvent event) {

    }

    @FXML
    void ColumnIva(ActionEvent event) {

    }

    @FXML
    void ColumnReferenciaProducto(ActionEvent event) {

    }

    @FXML
    void ColumnSubtotal(ActionEvent event) {

    }

    @FXML
    void InsertIdUsuario(MouseEvent event) {

    }

    @FXML
    void InsertIdVenta(MouseEvent event) {

    }

    @FXML
    void InsertIva(MouseEvent event) {

    }

    @FXML
    void InsertReferenciaProducto(MouseEvent event) {

    }

    @FXML
    void InsertSubtotal(MouseEvent event) {

    }

    @FXML
    void clickActualizar(MouseEvent event) {

    }

    @FXML
    void clickCrear(MouseEvent event) {

    }

    @FXML
    void insertIdFactura(MouseEvent event) {

    }

}
