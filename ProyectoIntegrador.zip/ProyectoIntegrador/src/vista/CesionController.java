package vista;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class CesionController {

    @FXML
    private Button buttonIngreso;

    @FXML
    private TextField textContraseña;

    @FXML
    private TextField textUser;

    @FXML
    void FacturaVista(ActionEvent event) {

    }

    @FXML
    void clickIngreso(MouseEvent event) {

    }

}
