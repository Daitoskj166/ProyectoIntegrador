package vista;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class FacturaVistaController {

    @FXML
    private TableColumn<?, ?> ColumnIdFactura;

    @FXML
    private TableColumn<?, ?> ColumnIdUsuario;

    @FXML
    private TableColumn<?, ?> ColumnIdVenta;

    @FXML
    private TableColumn<?, ?> ColumnIva;

    @FXML
    private TableColumn<?, ?> ColumnReferenciaProducto;

    @FXML
    private TableColumn<?, ?> ColumnSubtotal;

    @FXML
    private Button buttonActualizar;

    @FXML
    private Button buttonCrear;

    @FXML
    private TextField textIdFactura;

    @FXML
    private TextField textIdUsuario;

    @FXML
    private TextField textIdVenta;

    @FXML
    private TextField textIva;

    @FXML
    private TextField textReferenciaProducto;

    @FXML
    private TextField textSubtotal;

    @FXML
    void ColumnIdFactura(ActionEvent event) {

    }

    @FXML
    void ColumnIdUsuario(ActionEvent event) {

    }

    @FXML
    void ColumnIdVenta(ActionEvent event) {

    }

    @FXML
    void ColumnIva(ActionEvent event) {

    }

    @FXML
    void ColumnReferenciaProducto(ActionEvent event) {

    }

    @FXML
    void ColumnSubtotal(ActionEvent event) {

    }

    @FXML
    void InsertIdUsuario(MouseEvent event) {

    }

    @FXML
    void InsertIdVenta(MouseEvent event) {

    }

    @FXML
    void InsertIva(MouseEvent event) {

    }

    @FXML
    void InsertReferenciaProducto(MouseEvent event) {

    }

    @FXML
    void InsertSubtotal(MouseEvent event) {

    }

    @FXML
    void clickActualizar(MouseEvent event) {

    }

    @FXML
    void clickCrear(MouseEvent event) {

    }

    @FXML
    void insertIdFactura(MouseEvent event) {

    }
    
    @FXML
    private void initialize() {
        
        cargarFacturas();
    }

    @FXML
    private void agregarFactura() {
        
    }

    @FXML
    private void editarFactura() {
        
    }

    @FXML
    private void eliminarFactura() {
        
    }

    private void cargarFacturas() {
        
    }

}
